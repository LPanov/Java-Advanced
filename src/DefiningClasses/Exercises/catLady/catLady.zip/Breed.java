package DefiningClasses.Exercises.catLady;

public class Breed {

}
class Siamese extends Breed {
    String name;
    double earSize;


    public Siamese(String name, double earSize) {
        this.name = name;
        this.earSize = earSize;
    }

    public double getEarSize() {
        return earSize;
    }

    @Override
    public String toString() {
        return "Siamese " + name + " " + String.format("%.2f", earSize);
    }
}
class Cymric extends Breed {
    String name;
    double furLength;


    public Cymric(String name, double earSize) {
        this.name = name;
        this.furLength = earSize;
    }

    public double getFurLength() {
        return furLength;
    }

    @Override
    public String toString() {
        return "Cymric " + name + " " + String.format("%.2f", furLength);
    }
}

class StreetExtraordinaire extends Breed {
    String name;
    double meowSize;


    public StreetExtraordinaire(String name, double meowSize) {
        this.name = name;
        this.meowSize = meowSize;
    }

    public double getMeowSize() {
        return meowSize;
    }

    @Override
    public String toString() {
        return "StreetExtraordinaire " + name + " " + String.format("%.2f", meowSize);
    }
}
