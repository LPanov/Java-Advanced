package tanks;
// package RegularExam.tanks;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;

public class Terrain {
    private String type;
    private List<Tank> tanks;
    private int area;

    public Terrain(String type, int area) {
        this.type = type;
        this.tanks = new ArrayList<>();
        this.area = area;
    }

    public String addTank(Tank tank) {
       List<Tank> sameTanks = tanks.stream().filter(t -> t.getModel().equals(tank.getModel()) && t.getBrand().equals(tank.getBrand())).collect(Collectors.toList());
       if (!sameTanks.isEmpty()) {
           return "Tank with this brand and model already exists!";
       }
       else {
           if (this.type.equals("Swamp") && tank.getWeight() > 14000) {
               return "This "+tank.getBrand()+" is too heavy for this terrain!";
           }
           else {
               this.tanks.add(tank);
               return "Tank "+tank.getBrand()+" "+tank.getModel()+" added.";
           }
       }
    }

    public boolean removeTank(String brand, String model) {
        int index = -1;
        for (int i = 0; i < this.tanks.size(); i++) {
            if (this.tanks.get(i).getBrand().equals(brand) &&
                this.tanks.get(i).getModel().equals(model)) {
                index = i;
            }
        }
        if (index >= 0) {
            this.tanks.remove(index);
            return true;
        }
        return false;
    }

    public String getTanksByBarrelCaliberMoreThan(int barrelCaliber) {
        List<Tank> biggerTanks = this.tanks.stream().filter(t -> t.getBarrelCaliber() > barrelCaliber).collect(Collectors.toList());
        StringBuilder str = new StringBuilder();
        if (biggerTanks.isEmpty()) {
            str.append("There are no tanks with the specified caliber.");
        }
        else {
            str.append("Tanks with caliber more than ").append(barrelCaliber).append("mm: ");
            StringJoiner joiner = new StringJoiner(", ");
            biggerTanks.forEach(bt -> joiner.add(bt.getBrand()));
            str.append(joiner).append("\n");
        }
        return str.toString();
    }

    public Tank getTankByBrandAndModel(String brand, String model) {
        return tanks.stream()
                .filter(f -> f.getBrand().equals(brand))
                .filter(f -> f.getModel().equals(model))
                .findFirst().orElse(null);
    }

    public String getTheMostArmoredTank() {
        Tank mostArmoredTank = tanks.stream().max(Comparator.comparing(Tank::getArmour)).orElse(null);

        if (mostArmoredTank != null) {
            return String.format("%s %s is the most armored tank with %dmm. armor thickness.",
                    mostArmoredTank.getBrand(), mostArmoredTank.getModel(), mostArmoredTank.getArmour());
        }
        return "There are no tanks.";
    }

    public int getCount() {
        return tanks.size();
    }

    public String getStatistics() {
        StringBuilder str = new StringBuilder();
        if (tanks.isEmpty()) {
            str.append("There are no tanks in the ").append(this.type.toLowerCase()).append(".");
        }
        else {
            str.append("Tanks located in the ").append(this.type.toLowerCase()).append(":\n");
            tanks.forEach(tank -> str.append("-- ")
                    .append(tank.getBrand()).append(" ")
                    .append(tank.getModel()).append("\n"));
        }
        return str.toString();
    }
}
