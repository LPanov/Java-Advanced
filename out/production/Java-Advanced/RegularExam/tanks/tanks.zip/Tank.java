package tanks;
// package RegularExam.tanks;

public class Tank {
    private String brand;
    private String model;
    private int weight;
    private int barrelCaliber;
    private int armour;

    public Tank(String brand, String model, int weight, int barrelCaliber, int armour) {
        this.brand = brand;
        this.model = model;
        this.weight = weight;
        this.barrelCaliber = barrelCaliber;
        this.armour = armour;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public int getWeight() {
        return weight;
    }

    public int getBarrelCaliber() {
        return barrelCaliber;
    }

    public int getArmour() {
        return armour;
    }

    @Override
    public String toString() {
        return "Brand: "+this.brand+", Model: "+this.model+", Weight: "+this.weight+"kg, Barrel caliber: "+this.barrelCaliber+"mm, Armor: "+armour+"mm";
    }
}
