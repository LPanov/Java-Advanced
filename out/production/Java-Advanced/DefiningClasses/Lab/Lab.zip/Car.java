package DefiningClasses.Lab;

import java.util.Scanner;

public class Car {
    private String brand;
    private String model;
    private int horsepower;

    public Car(String brand, String model, int horsepower) {
        this.brand = brand;
        this.model = model;
        this.horsepower = horsepower;
    }

    public Car(String brand, String model) {
        this.brand = brand;
        this.model = model;
        this.horsepower = -1;
    }
    public Car(String brand, int horsepower) {
        this.brand = brand;
        this.model = "unknown";
        this.horsepower = horsepower;
    }
    public Car(String brand) {
        this.brand = brand;
        this.model = "unknown";
        this.horsepower = -1;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getHorsepower() {
        return horsepower;
    }

    public void setHorsepower(int horsepower) {
        this.horsepower = horsepower;
    }

    public String carInfo() {
        return "The car is: "+getBrand()+" "+getModel()+" – "+getHorsepower()+" HP.";
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < n; i++) {
            String[] input = scanner.nextLine().split("\\s+");
            Car car = null;
            if (input.length == 3) car = new Car(input[0], input[1], Integer.parseInt(input[2]));
            else if (input.length == 2) {
                if (Character.isDigit(input[1].charAt(0))) car = new Car(input[0], Integer.parseInt(input[1]));
                else car = new Car(input[0], input[1]);
            }
            else if (input.length == 1) car = new Car(input[0]);


            System.out.println(car.carInfo());
        }
    }
}
