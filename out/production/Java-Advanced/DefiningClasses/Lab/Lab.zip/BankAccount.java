package DefiningClasses.Lab;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class BankAccount {
    private final static  double DEFAULT_INTEREST_RATE = 0.02;
    private static double interestRate = DEFAULT_INTEREST_RATE;
    private static int bankAccountCount = 1;
    private int id;
    private double balance;

    BankAccount() {
        this.id = bankAccountCount++;
    }

    public int getId() {
        return id;
    }

    public double getBalance() {
        return balance;
    }

    public static void setInterestRate(double interestRate) {
        BankAccount.interestRate = interestRate;
    }

    void deposit (double amount) {
        this.balance += amount;
    }
    double getInterest (int years) {
        return BankAccount.interestRate * years * this.balance;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Map<Integer, BankAccount> accounts = new LinkedHashMap<>();

        String command = scanner.nextLine();
        while (!command.equals("End")) {
            String[] token = command.split("\\s+");
            if (token[0].equals("Create")) {
                BankAccount bankAccount = new BankAccount();
                accounts.putIfAbsent(bankAccount.getId(), bankAccount);
                System.out.println("Account ID"+bankAccount.getId()+" created");
            }
            else if (token[0].equals("Deposit")) {
                int id = Integer.parseInt(token[1]);
                double amount = Double.parseDouble(token[2]);
                if (accounts.containsKey(id)) {
                    System.out.println("Deposited "+String.format("%.0f", amount)+" to ID" + id);
                    accounts.get(id).deposit(amount);
                }
                else System.out.println("Account does not exist");
            }
            else if (token[0].equals("SetInterest")) {
                BankAccount.setInterestRate(Double.parseDouble(token[1]));
            }
            else if (token[0].equals("GetInterest")) {
                int id = Integer.parseInt(token[1]);
                int years = Integer.parseInt(token[2]);
                if (accounts.containsKey(id)) {
                    System.out.printf("%.2f%n", accounts.get(id).getInterest(years));
                }
                else System.out.println("Account does not exist");
            }

            command = scanner.nextLine();
        }
    }
}
